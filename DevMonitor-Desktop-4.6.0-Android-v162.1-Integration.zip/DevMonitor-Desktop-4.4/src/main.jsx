import React,{useEffect,useState} from 'react';
import {createRoot} from 'react-dom/client';
import {LayoutDashboard,MonitorSmartphone,Database,FileSpreadsheet,ArrowLeftRight,CreditCard,Settings,RefreshCw,Cloud,ClipboardList,StickyNote,TrendingUp,UserRound,Search} from 'lucide-react';
import './styles.css';
import Dashboard from './pages/Dashboard.jsx';
import DeviceMonitor from './pages/DeviceMonitor.jsx';
import Reports from './pages/Reports.jsx';
import MonthOnMonth from './pages/MonthOnMonth.jsx';
import Payment from './pages/Payment.jsx';
import MyDevices from './pages/MyDevices.jsx';
import SettingsPage from './pages/Settings.jsx';
import Tasks from './pages/Tasks.jsx';
import Notes from './pages/Notes.jsx';
import Timeline from './pages/Timeline.jsx';
import NextLevel from './pages/NextLevel.jsx';

const nav=[['Dashboard',LayoutDashboard],['Device Monitor',MonitorSmartphone],['My Devices',Database],['Reports',FileSpreadsheet],['Month-on-Month',ArrowLeftRight],['Payment',CreditCard],['Next Level',TrendingUp],['Tasks',ClipboardList],['Notes',StickyNote],['Activity Timeline',Search],['Settings',Settings]];
function App(){
 const [page,setPage]=useState('Dashboard'); const [summary,setSummary]=useState({observations:0,operations:0});
 const refresh=()=>window.devMonitor?.summary().then(setSummary);
 useEffect(()=>{refresh()},[]);
 const props={refreshSummary:refresh,summary};
 return <div className="app"><aside><div className="brand"><div className="logo">DM</div><div><b>DevMonitor</b><span>Desktop 4.6 · Android parity</span></div></div><nav>{nav.map(([n,I])=><button className={page===n?'active':''} onClick={()=>setPage(n)} key={n}><I size={19}/>{n}</button>)}</nav><div className="sidefoot"><div><Cloud size={15}/> Offline-ready</div><small>Local database active</small></div></aside><main><header><div><h1>{page}</h1><p>Windows desktop workspace</p></div><button className="refresh" onClick={refresh}><RefreshCw size={16}/> Refresh</button></header>{page==='Dashboard'&&<Dashboard {...props}/>} {page==='Device Monitor'&&<DeviceMonitor {...props}/>} {page==='My Devices'&&<MyDevices {...props}/>} {page==='Reports'&&<Reports {...props}/>} {page==='Month-on-Month'&&<MonthOnMonth {...props}/>} {page==='Payment'&&<Payment {...props}/>} {page==='Settings'&&<SettingsPage {...props}/>} {page==='Tasks'&&<Tasks/>} {page==='Notes'&&<Notes/>} {page==='Activity Timeline'&&<Timeline/>} {page==='Next Level'&&<NextLevel/>}</main></div>
}
createRoot(document.getElementById('root')).render(<App/>);
