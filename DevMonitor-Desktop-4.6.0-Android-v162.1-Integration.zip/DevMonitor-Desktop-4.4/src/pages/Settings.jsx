import React,{useState} from 'react';

export default function Settings({refreshSummary}){
  const [busy,setBusy]=useState(false);
  const [notice,setNotice]=useState('');
  const [error,setError]=useState('');
  async function run(action){
    setBusy(true);setNotice('');setError('');
    try{
      const result=await action();
      if(result?.canceled){setNotice('Operation cancelled.');return;}
      if(result?.path){setNotice('Synchronization file exported successfully. Keep this file safe and import it on the other device.');}
      else if(result){setNotice(`Import complete: ${result.devices} device records, ${result.observations} daily observations and ${result.operations} operations added or updated.`);await refreshSummary?.();}
    }catch(e){setError(e?.message||'The synchronization operation failed.');}
    finally{setBusy(false);}
  }
  return <section className="card">
    <h2>Settings</h2>
    <div className="setting"><b>Data storage</b><span>Local SQLite database</span></div>
    <div className="setting"><b>Synchronization format</b><span>DevMonitor Sync v1 · JSON</span></div>
    <p>Export a portable synchronization file, transfer it to the other device, then import it there. Imports merge records without deleting existing data. Newer device records and higher-priority observation values take precedence.</p>
    <div className="row">
      <button className="primary" disabled={busy} onClick={()=>run(()=>window.devMonitor.exportSync())}>Export Sync File</button>
      <button className="refresh" disabled={busy} onClick={()=>run(()=>window.devMonitor.importSync())}>Import Sync File</button>
    </div>
    {busy&&<div className="notice">Working…</div>}
    {notice&&<div className="notice" role="status">{notice}</div>}
    {error&&<div className="notice" role="alert">{error}</div>}
    <div className="setting"><b>Automatic phone ↔ PC sync</b><span>Not connected yet; this is the portable data-exchange foundation.</span></div>
  </section>
}
