# DevMonitor Desktop 4.6.0 — Android v162.1 Integration Pass

Windows desktop development source updated against Android **DevMonitor v162.1** and the existing Desktop 4.4 sync foundation.

## Included
- Electron + React + Vite desktop shell.
- Local SQLite database with normalized `device/date` observations.
- Excel `.xlsx` / `.xls` report import.
- Authoritative HQ imports are single-calendar-month snapshots; newer coverage replaces the whole month, duplicate/older coverage is rejected, and current/previous-month imports can arrive out of order.
- Import is intentionally isolated: it does not trigger Device Monitor, payment, dashboard, or Month-on-Month refreshes. Refreshes remain user initiated.
- Device Monitor observations are prevented from overwriting an imported report cell for the same device/date.
- My Devices persistent working set with **Update My Devices**.
- Calendar Month-on-Month comparison with an explicit cutoff date.
- Android 4.4 payment-cycle boundary: **21st through 20th**.
- Payment progression source rules: imported report cells are authoritative; Device Monitor/SMS Active can only fill dates after the latest imported row and cannot cross the payment-cycle boundary.
- Timestamped operation log with logical revision ordering.
- Versioned DevMonitor Sync v1 JSON export/import for portable two-way data exchange.
- Idempotent operation merging; imported records never delete existing data. Device records resolve by update time and daily observations by source priority, then received time.
- Windows NSIS installer configuration.
- Local Tasks, Notes, device activity timeline, dashboard search, and editable role/profile foundation.

## Windows / Visual Studio Terminal

```powershell
cd "C:\Path\To\DevMonitor-Desktop-4.4"
npm install
npm run dev
```

For a production installer:

```powershell
npm run dist
```

The installer is generated under `release/` after a successful Electron Builder run.

## Important
This package is the **development source baseline**, not a claimed prebuilt `.exe`. Electron main/preload syntax checks are required before packaging; runtime and installer behavior still need Windows verification. Android-only capabilities (SMS reception, SIM selection, Android billing/ads, Android notifications and Drive integration) are not directly portable and are not represented as completed PC features. Role-aware hierarchy is a profile foundation, not a full authorization migration.

## Portable synchronization (foundation)

Open **Settings** and use **Export Sync File** to create a `DevMonitor-sync.json` file.
Transfer that file to the other device and use **Import Sync File** there. Import is
additive/merge-only: it does not erase local records. The format is versioned (`devmonitor-sync`,
version `1`) and includes device records, normalized daily observations, and the operation log.
This is a manual transfer foundation; automatic network synchronization and Android-side
support are not included yet.
