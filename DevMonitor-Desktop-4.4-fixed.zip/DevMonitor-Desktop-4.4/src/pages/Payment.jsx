import {useState} from 'react';

export default function Payment({refreshSummary}){
 const [code,setCode]=useState('');
 const [r,setR]=useState(null);
 const [msg,setMsg]=useState('');
 const resolve=async()=>{if(!code.trim()){setMsg('Enter a device code.');return;} try{setMsg('');setR(await window.devMonitor.resolvePayment(code));}catch(e){setMsg(e.message)}};
 return <section className="card"><h2>Payment</h2><p>Current payment progression follows the Android 4.4 21st-to-20th cycle. Previous-cycle data is never carried into a new cycle.</p>
 <div className="row"><input value={code} onChange={e=>setCode(e.target.value)} placeholder="Device code"/><button className="primary" onClick={resolve}>Check progression</button></div>
 {msg&&<div className="notice">{msg}</div>}
 {r&&<div className="statrow"><div><b>Cycle</b><span>{r.cycleStart} → {r.cycleEnd}</span></div><div><b>As of</b><span>{r.asOf}</span></div><div><b>Current-cycle activations</b><span>{Number(r.total).toLocaleString()}</span></div><div><b>Data state</b><span>{r.complete?'Complete':'Partial / boundary not fully known'}</span></div></div>}
 {r&&<div className="notice">Sources: {r.sourceSummary||'No qualifying data yet.'}{r.smsOverrideToday!=null?` · SMS Today: ${r.smsOverrideToday}`:''}</div>}
 </section>
}
