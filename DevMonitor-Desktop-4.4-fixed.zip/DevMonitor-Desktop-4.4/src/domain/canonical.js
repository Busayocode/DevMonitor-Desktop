export function canonicalDeviceCode(code='') {
  const clean = code.trim().toUpperCase();
  const match = clean.match(/^(GLO-(?:GD|DD|FD))-(?:.+)-([A-Z0-9]+)$/);
  return match ? `${match[1]}-${match[2]}` : clean;
}

export function paymentCycleForDate(date) {
  const d = new Date(`${date}T00:00:00`);
  const y=d.getFullYear(), m=d.getMonth(), day=d.getDate();
  if(day>=21) return {start:new Date(y,m,21), end:new Date(y,m+1,20)};
  return {start:new Date(y,m-1,21), end:new Date(y,m,20)};
}

export function isoDate(d) { return d.toISOString().slice(0,10); }

export function makeOperation({deviceId='desktop',entityId,operationType,data,logicalRevision=Date.now()}) {
  return { operationId:crypto.randomUUID(), deviceId, timestamp:Date.now(), logicalRevision, entityId, operationType, data, source:'desktop' };
}
