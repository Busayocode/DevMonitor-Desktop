export function compareOperations(a,b) {
  return (a.logicalRevision-b.logicalRevision) || (a.timestamp-b.timestamp) || a.operationId.localeCompare(b.operationId);
}

export function mergeOperationLogs(local=[], remote=[]) {
  const map=new Map();
  [...local,...remote].forEach(op=>map.set(op.operationId,op));
  return [...map.values()].sort(compareOperations);
}

export function resolveEntityOperations(ops) {
  const latest=new Map();
  for(const op of [...ops].sort(compareOperations)) latest.set(`${op.entityId}:${op.operationType}`,op);
  return [...latest.values()];
}
