# DevMonitor Desktop 4.4

Windows desktop development baseline aligned to the Android **DevMonitor 4.4 release-ready fixed** source.

## Included
- Electron + React + Vite desktop shell.
- Local SQLite database with normalized `device/date` observations.
- Excel `.xlsx` / `.xls` report import.
- Newer imported report values replace older values for the same device/date.
- Device Monitor observations are prevented from overwriting an imported report cell for the same device/date.
- My Devices persistent working set with **Update My Devices**.
- Calendar Month-on-Month comparison with an explicit cutoff date.
- Android 4.4 payment-cycle boundary: **21st through 20th**.
- Payment progression source rules: imported report cells are authoritative; Device Monitor/SMS Active can only fill dates after the latest imported row and cannot cross the payment-cycle boundary.
- Timestamped operation log with logical revision ordering for future phone ↔ PC synchronization.
- Windows NSIS installer configuration.

## Windows / Visual Studio Terminal

```powershell
cd "C:\Path\To\DevMonitor-Desktop-4.4"
npm install
npm run dev
```

For a production installer:

```powershell
npm run dist
```

The installer is generated under `release/` after a successful Electron Builder run.

## Important
This package is the **development source baseline**, not a claimed prebuilt `.exe`. The assistant environment could syntax-check the Electron source but dependency installation did not finish within the available execution window.
