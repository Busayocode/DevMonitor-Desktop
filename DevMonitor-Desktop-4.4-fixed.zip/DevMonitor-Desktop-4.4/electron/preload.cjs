const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('devMonitor', {
  summary: () => ipcRenderer.invoke('db:summary'),
  saveOperation: (operation) => ipcRenderer.invoke('db:save-operation', operation),
  chooseAndImportReport: () => ipcRenderer.invoke('report:choose-and-import'),
  listDevices: () => ipcRenderer.invoke('devices:list'),
  addDevice: (code) => ipcRenderer.invoke('devices:add', code),
  removeDevice: (code) => ipcRenderer.invoke('devices:remove', code),
  recentObservations: (code) => ipcRenderer.invoke('observations:recent', code),
  saveObservation: (observation) => ipcRenderer.invoke('observations:save', observation),
  monthSummary: (asOf) => ipcRenderer.invoke('mom:summary', asOf),
  resolvePayment: (code) => ipcRenderer.invoke('payment:resolve', code),
  paymentLoaded: (code,start,end) => ipcRenderer.invoke('payment:loaded', code,start,end),
  paymentObservations: (code,start,end) => ipcRenderer.invoke('payment:observations', code,start,end),
  paymentBaseline: (code,date) => ipcRenderer.invoke('payment:baseline', code,date)
});
