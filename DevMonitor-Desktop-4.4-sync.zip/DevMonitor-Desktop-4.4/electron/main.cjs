const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');
const XLSX = require('xlsx');

let db;
const now = () => Date.now();
function canonicalDeviceCode(code='') {
  const clean = String(code).trim().toUpperCase();
  const m = clean.match(/^(GLO-(?:GD|DD|FD))-(?:.+)-([A-Z0-9]+)$/);
  return m ? `${m[1]}-${m[2]}` : clean;
}
function ownershipFor(code) {
  const c = canonicalDeviceCode(code);
  if (/^GLO-GD-/i.test(c)) return 'COMPANY';
  if (/^GLO-(DD|FD)-/i.test(c)) return 'PARTNER';
  return 'UNKNOWN';
}
function parseDate(v) {
  if (v instanceof Date && !Number.isNaN(v.getTime())) return v.toISOString().slice(0,10);
  if (typeof v === 'number') {
    const d = XLSX.SSF.parse_date_code(v);
    if (d?.y) return `${d.y.toString().padStart(4,'0')}-${d.m.toString().padStart(2,'0')}-${d.d.toString().padStart(2,'0')}`;
  }
  const s = String(v ?? '').trim(); if (!s) return null;
  let m = s.match(/^(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})$/); if (m) return `${m[1]}-${m[2].padStart(2,'0')}-${m[3].padStart(2,'0')}`;
  m = s.match(/^(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{4})$/); if (m) return `${m[3]}-${m[2].padStart(2,'0')}-${m[1].padStart(2,'0')}`;
  const d = new Date(s); return Number.isNaN(d.getTime()) ? null : d.toISOString().slice(0,10);
}
function initDb() {
  const dbPath = path.join(app.getPath('userData'), 'devmonitor.db');
  db = new Database(dbPath); db.pragma('journal_mode = WAL');
  db.exec(`
    CREATE TABLE IF NOT EXISTS daily_observations(code TEXT NOT NULL, obs_date TEXT NOT NULL, ownership TEXT NOT NULL,
      today INTEGER, mtd INTEGER, active INTEGER, bar48 INTEGER, bar96 INTEGER, duplicates INTEGER, monthly_target INTEGER,
      received_at TEXT, source_report TEXT, source_priority INTEGER DEFAULT 0, PRIMARY KEY(code, obs_date));
    CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
    CREATE TABLE IF NOT EXISTS my_devices(code TEXT PRIMARY KEY, added_at INTEGER NOT NULL, updated_at INTEGER NOT NULL, active INTEGER NOT NULL DEFAULT 1);
    CREATE TABLE IF NOT EXISTS reports(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, imported_at INTEGER NOT NULL,
      coverage_start TEXT, coverage_end TEXT, rows INTEGER NOT NULL DEFAULT 0, updated_cells INTEGER NOT NULL DEFAULT 0);
    CREATE TABLE IF NOT EXISTS operations(operation_id TEXT PRIMARY KEY, device_id TEXT NOT NULL, timestamp INTEGER NOT NULL,
      logical_revision INTEGER NOT NULL, entity_id TEXT NOT NULL, operation_type TEXT NOT NULL, payload_json TEXT NOT NULL,
      source TEXT NOT NULL, synced_at INTEGER);
    CREATE INDEX IF NOT EXISTS idx_operations_order ON operations(logical_revision, timestamp, operation_id);
    CREATE TABLE IF NOT EXISTS sync_state(key TEXT PRIMARY KEY, value TEXT);
  `);
}
function saveOperation(op) {
  db.prepare(`INSERT OR IGNORE INTO operations(operation_id,device_id,timestamp,logical_revision,entity_id,operation_type,payload_json,source,synced_at)
    VALUES(@operationId,@deviceId,@timestamp,@logicalRevision,@entityId,@operationType,@payloadJson,@source,NULL)`).run({
      operationId:op.operationId, deviceId:op.deviceId, timestamp:op.timestamp, logicalRevision:op.logicalRevision,
      entityId:op.entityId, operationType:op.operationType, payloadJson:JSON.stringify(op.data ?? {}), source:op.source ?? 'desktop'
    });
}
function importWorkbook(filePath) {
  const wb = XLSX.readFile(filePath, {cellDates:true, raw:true});
  const all = [];
  for (const sheetName of wb.SheetNames) {
    const rows = XLSX.utils.sheet_to_json(wb.Sheets[sheetName], {header:1, defval:null, raw:true});
    for (let r=0;r<rows.length;r++) {
      const row=rows[r] || [];
      const codeIdx=row.findIndex(v=>/^GLO-(GD|DD|FD)-/i.test(String(v??'')));
      if(codeIdx<0) continue;
      const code=canonicalDeviceCode(row[codeIdx]);
      for(let c=0;c<row.length;c++) {
        if(c===codeIdx) continue;
        const date=parseDate(rows[Math.max(0,r-1)]?.[c]);
        if(!date) continue;
        const value=Number(row[c]);
        if(!Number.isFinite(value)) continue;
        all.push({code,date,today:Math.trunc(value)});
      }
    }
  }
  // Also support vertical tables with explicit Date/Device/Today columns.
  for (const sheetName of wb.SheetNames) {
    const rows = XLSX.utils.sheet_to_json(wb.Sheets[sheetName], {header:1, defval:null, raw:true});
    const header=(rows[0]||[]).map(v=>String(v??'').trim().toLowerCase());
    const ci=header.findIndex(x=>/^(device|device code|code|simreg|serial)/.test(x));
    const di=header.findIndex(x=>/^(date|activation date|day)/.test(x));
    const ti=header.findIndex(x=>/^(today|activations?|daily activations?|sales)/.test(x));
    if(ci>=0 && di>=0 && ti>=0) for(let r=1;r<rows.length;r++) {
      const code=canonicalDeviceCode(rows[r]?.[ci]); const date=parseDate(rows[r]?.[di]); const value=Number(rows[r]?.[ti]);
      if(code && date && Number.isFinite(value)) all.push({code,date,today:Math.trunc(value)});
    }
  }
  const unique=new Map(all.map(x=>[`${x.code}|${x.date}`,x]));
  const rows=[...unique.values()];
  if(!rows.length) throw new Error('No device/date activation rows were recognized in this workbook.');
  const dates=rows.map(x=>x.date).sort(); const start=dates[0], end=dates[dates.length-1];
  const ins=db.prepare(`INSERT INTO daily_observations(code,obs_date,ownership,today,received_at,source_report,source_priority)
    VALUES(?,?,?,?,?,?,?) ON CONFLICT(code,obs_date) DO UPDATE SET
      ownership=excluded.ownership,today=excluded.today,received_at=excluded.received_at,source_report=excluded.source_report,source_priority=excluded.source_priority`);
  const report=db.prepare('INSERT INTO reports(name,imported_at,coverage_start,coverage_end,rows,updated_cells) VALUES(?,?,?,?,?,?)');
  let changed=0;
  const tx=db.transaction(()=>{ for(const x of rows){ const old=db.prepare('SELECT today,source_priority FROM daily_observations WHERE code=? AND obs_date=?').get(x.code,x.date); if(!old || old.today!==x.today) changed++; ins.run(x.code,x.date,ownershipFor(x.code),x.today,new Date().toISOString(),path.basename(filePath),Date.now()); } report.run(path.basename(filePath),now(),start,end,rows.length,changed); });
  tx();
  saveOperation({operationId:crypto.randomUUID(),deviceId:'desktop',timestamp:now(),logicalRevision:now(),entityId:path.basename(filePath),operationType:'REPORT_IMPORT',data:{coverageStart:start,coverageEnd:end,rows:rows.length,updatedCells:changed},source:'desktop'});
  return {name:path.basename(filePath),coverageStart:start,coverageEnd:end,rows:rows.length,updatedCells:changed};
}


const SYNC_FORMAT = 'devmonitor-sync';
const SYNC_VERSION = 1;
const SYNC_MAX_BYTES = 50 * 1024 * 1024;

function exportSyncBundle() {
  return {
    format: SYNC_FORMAT,
    version: SYNC_VERSION,
    exportedAt: new Date().toISOString(),
    deviceId: 'desktop',
    devices: db.prepare('SELECT code,added_at AS addedAt,updated_at AS updatedAt,active FROM my_devices ORDER BY code').all(),
    observations: db.prepare(`SELECT code,obs_date AS date,ownership,today,mtd,active,bar48,bar96,duplicates,
      monthly_target AS monthlyTarget,received_at AS receivedAt,source_report AS sourceReport,source_priority AS sourcePriority
      FROM daily_observations ORDER BY code,obs_date`).all(),
    operations: db.prepare(`SELECT operation_id AS operationId,device_id AS deviceId,timestamp,logical_revision AS logicalRevision,
      entity_id AS entityId,operation_type AS operationType,payload_json AS payloadJson,source,synced_at AS syncedAt
      FROM operations ORDER BY logical_revision,timestamp,operation_id`).all()
  };
}
function validSyncBundle(bundle) {
  if (!bundle || bundle.format !== SYNC_FORMAT || bundle.version !== SYNC_VERSION ||
      !Array.isArray(bundle.devices) || !Array.isArray(bundle.observations) || !Array.isArray(bundle.operations)) {
    throw new Error('This is not a supported DevMonitor synchronization file.');
  }
  if (bundle.devices.length + bundle.observations.length + bundle.operations.length > 250000) {
    throw new Error('The synchronization file contains too many records.');
  }
  for (const d of bundle.devices) {
    if (!d || typeof d.code !== 'string' || !d.code.trim() ||
        !Number.isFinite(Number(d.updatedAt)) || ![0,1].includes(Number(d.active))) {
      throw new Error('The synchronization file contains an invalid device record.');
    }
  }
  for (const o of bundle.observations) {
    if (!o || typeof o.code !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(String(o.date)) ||
        !Number.isFinite(Number(o.sourcePriority ?? 0))) {
      throw new Error('The synchronization file contains an invalid daily observation.');
    }
  }
  for (const op of bundle.operations) {
    if (!op || typeof op.operationId !== 'string' || !op.operationId ||
        typeof op.deviceId !== 'string' || !Number.isFinite(Number(op.timestamp)) ||
        !Number.isFinite(Number(op.logicalRevision)) || typeof op.entityId !== 'string' ||
        typeof op.operationType !== 'string' || typeof op.payloadJson !== 'string') {
      throw new Error('The synchronization file contains an invalid operation.');
    }
    try { JSON.parse(op.payloadJson); } catch { throw new Error('An operation has invalid JSON data.'); }
  }
}
function importSyncBundle(bundle) {
  validSyncBundle(bundle);
  const upsertDevice = db.prepare(`INSERT INTO my_devices(code,added_at,updated_at,active) VALUES(?,?,?,?)
    ON CONFLICT(code) DO UPDATE SET added_at=MIN(my_devices.added_at,excluded.added_at),
      updated_at=excluded.updated_at,active=excluded.active WHERE excluded.updated_at>my_devices.updated_at`);
  const upsertObservation = db.prepare(`INSERT INTO daily_observations(code,obs_date,ownership,today,mtd,active,bar48,bar96,
    duplicates,monthly_target,received_at,source_report,source_priority) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)
    ON CONFLICT(code,obs_date) DO UPDATE SET ownership=excluded.ownership,today=excluded.today,mtd=excluded.mtd,
      active=excluded.active,bar48=excluded.bar48,bar96=excluded.bar96,duplicates=excluded.duplicates,
      monthly_target=excluded.monthly_target,received_at=excluded.received_at,source_report=excluded.source_report,
      source_priority=excluded.source_priority
    WHERE excluded.source_priority>daily_observations.source_priority
      OR (excluded.source_priority=daily_observations.source_priority AND
        COALESCE(excluded.received_at,'')>COALESCE(daily_observations.received_at,''))`);
  const insertOperation = db.prepare(`INSERT OR IGNORE INTO operations(operation_id,device_id,timestamp,logical_revision,
    entity_id,operation_type,payload_json,source,synced_at) VALUES(?,?,?,?,?,?,?,?,?)`);
  let devices=0, observations=0, operations=0;
  const tx=db.transaction(()=>{
    for(const d of bundle.devices) {
      const before=db.prepare('SELECT updated_at,active FROM my_devices WHERE code=?').get(d.code);
      upsertDevice.run(d.code,Number(d.addedAt)||Number(d.updatedAt),Number(d.updatedAt),Number(d.active));
      const after=db.prepare('SELECT updated_at,active FROM my_devices WHERE code=?').get(d.code);
      if(!before || before.updated_at!==after.updated_at || before.active!==after.active) devices++;
    }
    for(const o of bundle.observations) {
      const before=db.prepare('SELECT source_priority,received_at,today,active FROM daily_observations WHERE code=? AND obs_date=?').get(o.code,o.date);
      upsertObservation.run(o.code,o.date,o.ownership||ownershipFor(o.code),o.today??null,o.mtd??null,o.active??null,
        o.bar48??null,o.bar96??null,o.duplicates??null,o.monthlyTarget??null,o.receivedAt??null,o.sourceReport??null,
        Number(o.sourcePriority)||0);
      const after=db.prepare('SELECT source_priority,received_at,today,active FROM daily_observations WHERE code=? AND obs_date=?').get(o.code,o.date);
      if(!before || before.source_priority!==after.source_priority || before.received_at!==after.received_at ||
          before.today!==after.today || before.active!==after.active) observations++;
    }
    for(const op of bundle.operations) {
      const r=insertOperation.run(op.operationId,op.deviceId,Number(op.timestamp),Number(op.logicalRevision),op.entityId,
        op.operationType,op.payloadJson,op.source||'unknown',op.syncedAt??null);
      operations+=r.changes;
    }
    db.prepare(`INSERT INTO sync_state(key,value) VALUES('last_import_at',?)
      ON CONFLICT(key) DO UPDATE SET value=excluded.value`).run(new Date().toISOString());
  });
  tx();
  return {devices,observations,operations};
}
ipcMain.handle('sync:export',async()=>{
  const r=await dialog.showSaveDialog({defaultPath:'DevMonitor-sync.json',filters:[{name:'DevMonitor sync',extensions:['json']}]});
  if(r.canceled||!r.filePath) return {canceled:true};
  fs.writeFileSync(r.filePath,JSON.stringify(exportSyncBundle(),null,2),'utf8');
  return {canceled:false,path:r.filePath};
});
ipcMain.handle('sync:import',async()=>{
  const r=await dialog.showOpenDialog({properties:['openFile'],filters:[{name:'DevMonitor sync',extensions:['json']}]});
  if(r.canceled||!r.filePaths[0]) return {canceled:true};
  const file=r.filePaths[0];
  if(fs.statSync(file).size>SYNC_MAX_BYTES) throw new Error('The synchronization file is larger than 50 MB.');
  const bundle=JSON.parse(fs.readFileSync(file,'utf8'));
  return {canceled:false,...importSyncBundle(bundle)};
});

ipcMain.handle('db:summary',()=>({
  observations:db.prepare('SELECT COUNT(*) c FROM daily_observations').get().c,
  operations:db.prepare('SELECT COUNT(*) c FROM operations').get().c,
  devices:db.prepare('SELECT COUNT(*) c FROM my_devices WHERE active=1').get().c,
  reports:db.prepare('SELECT COUNT(*) c FROM reports').get().c,
  dbPath:path.join(app.getPath('userData'),'devmonitor.db')
}));
ipcMain.handle('db:save-operation',(_,op)=>{saveOperation(op);return true;});
ipcMain.handle('report:choose-and-import',async()=>{const r=await dialog.showOpenDialog({properties:['openFile'],filters:[{name:'Excel reports',extensions:['xlsx','xls']}]});if(r.canceled||!r.filePaths[0])return {canceled:true};return importWorkbook(r.filePaths[0]);});
ipcMain.handle('devices:list',()=>db.prepare('SELECT code,added_at as addedAt,updated_at as updatedAt FROM my_devices WHERE active=1 ORDER BY code').all());
ipcMain.handle('devices:add',(_,code)=>{const c=canonicalDeviceCode(code);if(!c)throw new Error('Device code is required');const t=now();db.prepare(`INSERT INTO my_devices(code,added_at,updated_at,active) VALUES(?,?,?,1) ON CONFLICT(code) DO UPDATE SET updated_at=excluded.updated_at,active=1`).run(c,t,t);saveOperation({operationId:crypto.randomUUID(),deviceId:'desktop',timestamp:t,logicalRevision:t,entityId:c,operationType:'MY_DEVICE_ADD',data:{code:c},source:'desktop'});return true;});
ipcMain.handle('devices:remove',(_,code)=>{const c=canonicalDeviceCode(code);db.prepare('UPDATE my_devices SET active=0,updated_at=? WHERE code=?').run(now(),c);saveOperation({operationId:crypto.randomUUID(),deviceId:'desktop',timestamp:now(),logicalRevision:now(),entityId:c,operationType:'MY_DEVICE_REMOVE',data:{code:c},source:'desktop'});return true;});
ipcMain.handle('observations:save',(_,o)=>{const code=canonicalDeviceCode(o.code);const date=parseDate(o.date)||new Date().toISOString().slice(0,10);const t=now();db.prepare(`INSERT INTO daily_observations(code,obs_date,ownership,today,mtd,active,bar48,bar96,duplicates,monthly_target,received_at,source_report,source_priority) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(code,obs_date) DO UPDATE SET today=excluded.today,mtd=excluded.mtd,active=excluded.active,bar48=excluded.bar48,bar96=excluded.bar96,duplicates=excluded.duplicates,monthly_target=excluded.monthly_target,received_at=excluded.received_at,source_report=excluded.source_report,source_priority=excluded.source_priority WHERE daily_observations.source_priority>excluded.source_priority`).run(code,date,ownershipFor(code),Number(o.today)||0,o.mtd===''?null:Number(o.mtd),o.active===''?null:Number(o.active),o.bar48===''?null:Number(o.bar48),o.bar96===''?null:Number(o.bar96),o.duplicates===''?null:Number(o.duplicates),o.monthlyTarget===''?null:Number(o.monthlyTarget),new Date(t).toISOString(),'Device Monitor',20);saveOperation({operationId:crypto.randomUUID(),deviceId:'desktop',timestamp:t,logicalRevision:t,entityId:code,operationType:'DEVICE_MONITOR_OBSERVATION',data:{code,date,...o},source:'desktop'});return true;});
ipcMain.handle('observations:recent',(_,code)=>{if(code)return db.prepare('SELECT * FROM daily_observations WHERE code=? ORDER BY obs_date DESC LIMIT 60').all(canonicalDeviceCode(code));return db.prepare('SELECT * FROM daily_observations ORDER BY obs_date DESC,code LIMIT 200').all();});
ipcMain.handle('mom:summary',(_,asOf)=>{
  // Use calendar components rather than Date#setMonth: changing the month
  // on dates such as March 31 can overflow into the following month.
  const selected = /^\d{4}-\d{2}-\d{2}$/.test(String(asOf||''))
    ? String(asOf) : new Date().toISOString().slice(0,10);
  const [year, monthNumber, day] = selected.split('-').map(Number);
  const monthStart = `${year}-${String(monthNumber).padStart(2,'0')}-01`;
  const prevMonthDate = new Date(Date.UTC(year, monthNumber - 2, 1));
  const prevYear = prevMonthDate.getUTCFullYear();
  const prevMonthNumber = prevMonthDate.getUTCMonth() + 1;
  const prevMonth = `${prevYear}-${String(prevMonthNumber).padStart(2,'0')}`;
  const daysInPreviousMonth = new Date(Date.UTC(prevYear, prevMonthNumber, 0)).getUTCDate();
  const prevEnd = Math.min(day, daysInPreviousMonth);
  const previousEnd = `${prevMonth}-${String(prevEnd).padStart(2,'0')}`;
  const current = db.prepare(
    "SELECT COALESCE(SUM(today),0) total FROM daily_observations WHERE obs_date BETWEEN ? AND ?"
  ).get(monthStart, selected).total;
  const previous = db.prepare(
    "SELECT COALESCE(SUM(today),0) total FROM daily_observations WHERE obs_date BETWEEN ? AND ?"
  ).get(`${prevMonth}-01`, previousEnd).total;
  return {asOf:selected,current,previous,delta:current-previous,
    percent:previous?((current-previous)/previous*100):null};
});
ipcMain.handle('payment:resolve',(_,deviceId,asOf)=>{
  const code=canonicalDeviceCode(deviceId); const date=asOf||new Date().toISOString().slice(0,10); const d=new Date(`${date}T00:00:00`);
  const start=new Date(d.getFullYear(),d.getMonth()-(d.getDate()<21?1:0),21); const end=new Date(start.getFullYear(),start.getMonth()+1,20); const endDate=new Date(Math.min(end.getTime(),d.getTime()));
  const ds=x=>x.toISOString().slice(0,10), startS=ds(start), endS=ds(end), lastS=ds(endDate);
  const loaded=db.prepare(`SELECT obs_date,today,active FROM daily_observations WHERE code=? AND obs_date BETWEEN ? AND ? AND source_report<>? ORDER BY obs_date`).all(code,startS,lastS,'Device Monitor');
  const obs=db.prepare(`SELECT obs_date,today,active FROM daily_observations WHERE code=? AND obs_date BETWEEN ? AND ? AND (active IS NOT NULL OR today IS NOT NULL) ORDER BY obs_date`).all(code,startS,lastS);
  const map=new Map(loaded.map(x=>[x.obs_date,x])); let total=loaded.reduce((n,x)=>n+Math.max(0,Number(x.today)||0),0), knownFrom=loaded[0]?.obs_date||null, complete=true, sources=[];
  if(loaded.length){ sources.push(`Normalized Loaded Reports ${startS}..${lastS} (authoritative)`); const latest=loaded.at(-1).obs_date; const baseline=obs.find(x=>x.obs_date===latest&&x.active!=null); const after=obs.filter(x=>x.obs_date>latest&&x.active!=null); if(after.length&&baseline){let prev=Number(baseline.active)||0; for(const x of after){const cur=Number(x.active)||prev; total+=Math.max(0,cur-prev); prev=cur;} sources.push('Device Monitor SMS delta after latest report');} for(let q=new Date(start);q<=endDate;q.setDate(q.getDate()+1)) if(!map.has(ds(q))) complete=false; }
  else if(obs.length){ const first=obs[0], b=db.prepare(`SELECT active FROM daily_observations WHERE code=? AND obs_date<? AND active IS NOT NULL ORDER BY obs_date DESC LIMIT 1`).get(code,first.obs_date); if(b?.active!=null){total=Math.max(0,(Number(first.active)||0)-Number(b.active));knownFrom=startS;sources.push('Device Monitor SMS Active');}else{total=Math.max(0,Number(first.today)||0);knownFrom=first.obs_date;complete=false;sources.push(`Device Monitor SMS from ${first.obs_date}`);} let prev=Number(first.active)||0; for(const x of obs.slice(1)){const cur=x.active==null?prev:Number(x.active)||0;total+=Math.max(0,cur-prev);prev=cur;} }
  else {complete=false;sources.push('No qualifying current-cycle data');}
  return {cycleStart:startS,cycleEnd:endS,asOf:date,total,knownFrom,complete,sourceSummary:sources.join('; '),smsOverrideToday:obs.find(x=>x.obs_date===lastS)?.today??null};
});
ipcMain.handle('payment:loaded',(_,code,start,end)=>db.prepare(`SELECT code,obs_date,today,active,source_report,source_priority FROM daily_observations WHERE code=? AND obs_date BETWEEN ? AND ? AND source_report<>? ORDER BY obs_date`).all(canonicalDeviceCode(code),start,end,'Device Monitor'));
ipcMain.handle('payment:observations',(_,code,start,end)=>db.prepare(`SELECT code,obs_date,today,mtd,active,source_report,source_priority FROM daily_observations WHERE code=? AND obs_date BETWEEN ? AND ? ORDER BY obs_date`).all(canonicalDeviceCode(code),start,end));
ipcMain.handle('payment:baseline',(_,code,date)=>{
  const c=canonicalDeviceCode(code);
  const before=db.prepare(`SELECT active FROM daily_observations WHERE code=? AND obs_date<? AND active IS NOT NULL ORDER BY obs_date DESC LIMIT 1`).get(c,date);
  if(before?.active!=null) return before.active;
  const d=new Date(`${date}T00:00:00`); const month=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`;
  const rows=db.prepare(`SELECT obs_date,today FROM daily_observations WHERE code=? AND obs_date LIKE ? AND obs_date<? AND source_report<>? ORDER BY obs_date`).all(c,`${month}-%`,date,'Device Monitor');
  if(!rows.length) return null;
  const expected=new Date(d.getFullYear(),d.getMonth(),d.getDate()-1).getDate();
  const first=rows[0].obs_date;
  if(first!==`${month}-01` || rows.length<expected) return null;
  return rows.reduce((n,x)=>n+Math.max(0,Number(x.today)||0),0);
});
function createWindow(){const win=new BrowserWindow({width:1440,height:920,minWidth:1100,minHeight:700,webPreferences:{preload:path.join(__dirname,'preload.cjs'),contextIsolation:true,nodeIntegration:false}});if(!app.isPackaged)win.loadURL('http://127.0.0.1:5173');else win.loadFile(path.join(__dirname,'../dist/index.html'));}
app.whenReady().then(()=>{initDb();createWindow();app.on('activate',()=>{if(BrowserWindow.getAllWindows().length===0)createWindow();});});
app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit();});
