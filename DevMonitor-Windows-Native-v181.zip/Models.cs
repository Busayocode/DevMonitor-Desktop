namespace DevMonitor.Windows;

public sealed record DeviceRow(
    string DeviceId,
    string TradeCode,
    string PartnerName,
    string Cluster,
    string Region,
    string Territory,
    string StaffName,
    Dictionary<DateTime,int> Daily);

public sealed record DeviceSnapshot(
    string DeviceId, string Source, string Ownership,
    int Today, int Mtd, int Active, int Bar48, int Bar96,
    DateTime AsOf, string? Flag);

public sealed record IncentiveEstimate(
    int Activations, int FixedReward, int RechargeBonus,
    int SundayActivations, int SundayBonus, int Subtotal,
    int? NextThreshold, int ActivationsToNext, int? NextReward);

public sealed record ReportInfo(
    string Id, DateTime Month, DateTime CoverageStart, DateTime CoverageEnd,
    string SourceFile, DateTime ImportedAt, int DeviceCount);
