$ErrorActionPreference="Stop"
dotnet restore
dotnet publish .\DevMonitor.Windows.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o .\publish
Write-Host "Build complete: $PWD\publish\DevMonitor.exe"
