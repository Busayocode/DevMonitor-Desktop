using System.Windows;
namespace DevMonitor.Windows;
public partial class App : Application { }
