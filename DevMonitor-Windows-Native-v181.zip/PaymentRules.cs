namespace DevMonitor.Windows;

public static class PaymentRules
{
    private static readonly (int Threshold, int Reward)[] Tiers =
    [
        (30, 9000), (50, 22500), (70, 35000), (100, 65000),
        (150, 90000), (200, 110000), (250, 135000), (300, 150000)
    ];

    public const int MinRechargeNaira = 200;
    public const int FrcPerActivation = 250;
    public const int SundayExtraPerActivation = 200;
    public const int SundayMinimumActivations = 5;
    public const int DefaultPartnerMinimum = 500;

    public static DateTime CurrentAwareDate(DateTime requested)
        => requested.Date > DateTime.Today ? DateTime.Today : requested.Date;

    public static (DateTime Start, DateTime End) PaymentCycleForDate(DateTime requested)
    {
        var date = CurrentAwareDate(requested);
        return date.Day >= 21
            ? (new DateTime(date.Year,date.Month,21), new DateTime(date.AddMonths(1).Year,date.AddMonths(1).Month,20))
            : (new DateTime(date.AddMonths(-1).Year,date.AddMonths(-1).Month,21), new DateTime(date.Year,date.Month,20));
    }

    public static string PaymentCycleLabel(DateTime requested) {
        var (s,e)=PaymentCycleForDate(requested); return $"{s:yyyy-MM-dd} → {e:yyyy-MM-dd}";
    }

    public static (DateTime Start, DateTime End) MyDevicesWorkingWindow(DateTime requested)
    {
        var date=CurrentAwareDate(requested);
        return date.Day >= 21
            ? (new DateTime(date.Year,date.Month,1), date)
            : (new DateTime(date.AddMonths(-1).Year,date.AddMonths(-1).Month,21), date);
    }

    public static IncentiveEstimate Estimate(int activations, int sundayActivations=0)
    {
        var n=Math.Max(0,activations);
        var sunday=Math.Clamp(sundayActivations,0,n);
        var fixedReward=Tiers.LastOrDefault(t=>n>=t.Threshold).Reward;
        var next=Tiers.FirstOrDefault(t=>n<t.Threshold);
        var hasNext=next.Threshold!=0;
        var qualifyingSunday=sunday>=SundayMinimumActivations?sunday:0;
        var sundayBonus=qualifyingSunday*SundayExtraPerActivation;
        var recharge=n*FrcPerActivation;
        return new IncentiveEstimate(n,fixedReward,recharge,sunday,sundayBonus,
            fixedReward+recharge+sundayBonus,hasNext?next.Threshold:null,
            hasNext?next.Threshold-n:0,hasNext?next.Reward:null);
    }

    public static int QualifyingSundayActivations(Dictionary<DateTime,int> daily, DateTime month, int cutoffDay)
    {
        var end=Math.Clamp(cutoffDay,0,DateTime.DaysInMonth(month.Year,month.Month));
        var total=0;
        for(int d=1;d<=end;d++) {
            var day=new DateTime(month.Year,month.Month,d);
            if(day.DayOfWeek==DayOfWeek.Sunday && daily.TryGetValue(day,out var n) && n>=SundayMinimumActivations) total+=n;
        }
        return total;
    }
}
