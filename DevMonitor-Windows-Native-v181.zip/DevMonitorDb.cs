using Microsoft.Data.Sqlite;

namespace DevMonitor.Windows;

public sealed class DevMonitorDb : IDisposable
{
    private readonly SqliteConnection _db;
    public string FilePath { get; }

    public DevMonitorDb()
    {
        var dir=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"DevMonitor");
        Directory.CreateDirectory(dir);
        FilePath=Path.Combine(dir,"devmonitor.db");
        _db=new SqliteConnection($"Data Source={FilePath}");
        _db.Open();
        Initialize();
    }

    private void Initialize()
    {
        using var cmd=_db.CreateCommand();
        cmd.CommandText="""
        PRAGMA journal_mode=WAL;
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT);
        CREATE TABLE IF NOT EXISTS my_devices(device_id TEXT PRIMARY KEY,updated_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS daily_observations(
            device_id TEXT NOT NULL, obs_date TEXT NOT NULL, ownership TEXT,
            today INTEGER, mtd INTEGER, active INTEGER, bar48 INTEGER, bar96 INTEGER,
            trade_code TEXT, partner_name TEXT, cluster TEXT, region TEXT, territory TEXT, staff_name TEXT,
            PRIMARY KEY(device_id,obs_date));
        CREATE TABLE IF NOT EXISTS hq_months(
            month TEXT PRIMARY KEY, coverage_start TEXT NOT NULL, coverage_end TEXT NOT NULL,
            source_file TEXT NOT NULL, imported_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS hq_rows(
            month TEXT NOT NULL, device_id TEXT NOT NULL, trade_code TEXT, partner_name TEXT,
            cluster TEXT, region TEXT, territory TEXT, staff_name TEXT, obs_date TEXT NOT NULL, value INTEGER NOT NULL,
            PRIMARY KEY(month,device_id,obs_date));
        CREATE TABLE IF NOT EXISTS sms_inbox(
            id INTEGER PRIMARY KEY AUTOINCREMENT,sender TEXT NOT NULL,body TEXT NOT NULL,received_at TEXT NOT NULL);
        """;
        cmd.ExecuteNonQuery();
    }

    public void SetSetting(string key,string value) {
        using var c=_db.CreateCommand(); c.CommandText="INSERT INTO settings(key,value) VALUES($k,$v) ON CONFLICT(key) DO UPDATE SET value=$v";
        c.Parameters.AddWithValue("$k",key); c.Parameters.AddWithValue("$v",value); c.ExecuteNonQuery();
    }
    public string? GetSetting(string key) {
        using var c=_db.CreateCommand(); c.CommandText="SELECT value FROM settings WHERE key=$k"; c.Parameters.AddWithValue("$k",key);
        return c.ExecuteScalar()?.ToString();
    }
    public void ReplaceMyDevices(IEnumerable<string> ids) {
        using var tx=_db.BeginTransaction();
        using(var c=_db.CreateCommand()){c.Transaction=tx;c.CommandText="DELETE FROM my_devices";c.ExecuteNonQuery();}
        foreach(var id in ids.Where(x=>!string.IsNullOrWhiteSpace(x)).Select(Canonical).Distinct()){
            using var c=_db.CreateCommand(); c.Transaction=tx;c.CommandText="INSERT INTO my_devices(device_id,updated_at) VALUES($id,$at)";
            c.Parameters.AddWithValue("$id",id);c.Parameters.AddWithValue("$at",DateTime.UtcNow.ToString("O"));c.ExecuteNonQuery();
        }
        tx.Commit();
    }
    public List<string> MyDevices(){
        using var c=_db.CreateCommand();c.CommandText="SELECT device_id FROM my_devices ORDER BY device_id";
        using var r=c.ExecuteReader();var o=new List<string>();while(r.Read())o.Add(r.GetString(0));return o;
    }

    public void ReplaceMonthSnapshot(DateTime month,DateTime start,DateTime end,string source,List<DeviceRow> rows)
    {
        var monthKey=new DateTime(month.Year,month.Month,1).ToString("yyyy-MM");
        using var tx=_db.BeginTransaction();
        using(var c=_db.CreateCommand()){c.Transaction=tx;c.CommandText="DELETE FROM hq_rows WHERE month=$m";c.Parameters.AddWithValue("$m",monthKey);c.ExecuteNonQuery();}
        foreach(var row in rows){
            foreach(var kv in row.Daily){
                if(kv.Key.Date<start.Date || kv.Key.Date>end.Date) continue;
                using var c=_db.CreateCommand();c.Transaction=tx;
                c.CommandText="""INSERT INTO hq_rows(month,device_id,trade_code,partner_name,cluster,region,territory,staff_name,obs_date,value)
                                 VALUES($m,$id,$t,$p,$c,$r,$te,$s,$d,$v)""";
                c.Parameters.AddWithValue("$m",monthKey);c.Parameters.AddWithValue("$id",Canonical(row.DeviceId));
                c.Parameters.AddWithValue("$t",row.TradeCode);c.Parameters.AddWithValue("$p",row.PartnerName);
                c.Parameters.AddWithValue("$c",row.Cluster);c.Parameters.AddWithValue("$r",row.Region);
                c.Parameters.AddWithValue("$te",row.Territory);c.Parameters.AddWithValue("$s",row.StaffName);
                c.Parameters.AddWithValue("$d",kv.Key.ToString("yyyy-MM-dd"));c.Parameters.AddWithValue("$v",kv.Value);
                c.ExecuteNonQuery();
            }
        }
        using(var c=_db.CreateCommand()){c.Transaction=tx;c.CommandText="""INSERT INTO hq_months(month,coverage_start,coverage_end,source_file,imported_at)
            VALUES($m,$s,$e,$f,$i) ON CONFLICT(month) DO UPDATE SET coverage_start=$s,coverage_end=$e,source_file=$f,imported_at=$i""";
            c.Parameters.AddWithValue("$m",monthKey);c.Parameters.AddWithValue("$s",start.ToString("yyyy-MM-dd"));
            c.Parameters.AddWithValue("$e",end.ToString("yyyy-MM-dd"));c.Parameters.AddWithValue("$f",source);c.Parameters.AddWithValue("$i",DateTime.UtcNow.ToString("O"));c.ExecuteNonQuery();}
        tx.Commit();
    }

    public DateTime? StoredCoverageEnd(DateTime month){
        using var c=_db.CreateCommand();c.CommandText="SELECT coverage_end FROM hq_months WHERE month=$m";c.Parameters.AddWithValue("$m",new DateTime(month.Year,month.Month,1).ToString("yyyy-MM"));
        var x=c.ExecuteScalar()?.ToString();return DateTime.TryParse(x,out var d)?d:null;
    }

    public List<DeviceSnapshot> DeviceSnapshots(IEnumerable<string> deviceIds,DateTime asOf)
    {
        var ids=deviceIds.Select(Canonical).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var result=new List<DeviceSnapshot>();
        foreach(var id in ids){
            using var c=_db.CreateCommand(); c.CommandText="""SELECT obs_date,value,ownership FROM hq_rows
                WHERE device_id=$id AND obs_date<= $d ORDER BY obs_date DESC LIMIT 40""";
            c.Parameters.AddWithValue("$id",id);c.Parameters.AddWithValue("$d",asOf.ToString("yyyy-MM-dd"));
            using var r=c.ExecuteReader();var daily=new List<(DateTime d,int v)>();string own="";
            while(r.Read()){daily.Add((DateTime.Parse(r.GetString(0)),r.GetInt32(1)));own=r.IsDBNull(2)?"":r.GetString(2);}
            if(daily.Count==0){result.Add(new DeviceSnapshot(id,"HQ","",0,0,0,0,0,asOf,"No HQ activity"));continue;}
            var today=daily.FirstOrDefault().v;
            var mtd=daily.Where(x=>x.d.Month==asOf.Month&&x.d.Year==asOf.Year).Sum(x=>x.v);
            var cycle=PaymentRules.PaymentCycleForDate(asOf);
            var active=daily.Where(x=>x.d>=cycle.Start&&x.d<=asOf).Sum(x=>x.v);
            result.Add(new DeviceSnapshot(id,"HQ",own,today,mtd,active,0,0,asOf,null));
        }
        return result;
    }

    public List<DeviceRow> LoadMonth(DateTime month)
    {
        var key=new DateTime(month.Year,month.Month,1).ToString("yyyy-MM");
        using var c=_db.CreateCommand();c.CommandText="""SELECT device_id,trade_code,partner_name,cluster,region,territory,staff_name,obs_date,value
            FROM hq_rows WHERE month=$m ORDER BY device_id,obs_date""";c.Parameters.AddWithValue("$m",key);
        using var r=c.ExecuteReader();var map=new Dictionary<string,DeviceRow>(StringComparer.OrdinalIgnoreCase);
        while(r.Read()){
            var id=r.GetString(0);
            if(!map.TryGetValue(id,out var row)){row=new DeviceRow(id,r.GetString(1),r.GetString(2),r.GetString(3),r.GetString(4),r.GetString(5),r.GetString(6),new());map[id]=row;}
            row.Daily[DateTime.Parse(r.GetString(7))]=r.GetInt32(8);
        }
        return map.Values.ToList();
    }
    public void AddSms(string sender,string body){
        using var c=_db.CreateCommand();c.CommandText="INSERT INTO sms_inbox(sender,body,received_at) VALUES($s,$b,$t)";
        c.Parameters.AddWithValue("$s",sender);c.Parameters.AddWithValue("$b",body);c.Parameters.AddWithValue("$t",DateTime.Now.ToString("O"));c.ExecuteNonQuery();
    }
    public List<(string Sender,string Body,DateTime Received)> Sms(){
        using var c=_db.CreateCommand();c.CommandText="SELECT sender,body,received_at FROM sms_inbox ORDER BY id DESC LIMIT 200";using var r=c.ExecuteReader();
        var list=new List<(string,string,DateTime)>();while(r.Read())list.Add((r.GetString(0),r.GetString(1),DateTime.Parse(r.GetString(2))));return list;
    }
    public static string Canonical(string id)=>Regex.Replace(id.Trim().ToUpperInvariant(),"[^A-Z0-9]","");
    public void Dispose()=>_db.Dispose();
}
