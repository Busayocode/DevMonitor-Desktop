# DevMonitor — Native Windows Edition (source v181)

This project is a **real Windows desktop application** rebuilt from the supplied
DevMonitor Android v181 source. It does not use a web renderer, Vite, React,
Electron, or a browser window.

## What is carried over

- Dashboard / control-centre workflow
- SMS Checker desktop/sync boundary
- My Devices working set
- HQ/SIMReg Excel import
- Current + previous calendar month HQ storage
- Replace-All authoritative monthly snapshots
- Out-of-order month import
- Older coverage rejection
- Payment cycle dates (21st–20th)
- Active as the payment/progression input
- Activation reward tiers and Sunday qualification
- Earning Progress view
- Agents & Partners foundation
- Local/offline-first SQLite persistence
- Windows file dialogs and desktop navigation

## Important Windows difference

A Windows PC cannot directly read the Android phone's SIM SMS inbox.
The desktop SMS Checker therefore has a local inbox/sync boundary: SMS text can
be supplied by a future Android-to-PC bridge, or entered/imported for testing.
The PC architecture keeps SMS ingestion separate from the calculation engine.

## Build

Requirements:
- Windows 10/11
- .NET 8 SDK

Run:

    powershell -ExecutionPolicy Bypass -File .\BUILD_WINDOWS.ps1

The result is a self-contained `DevMonitor.exe` under `publish`.

## GitHub Actions

`.github/workflows/build-windows.yml` builds the self-contained Windows x64
application and uploads it as an artifact.

## Data

The application creates:

`%LOCALAPPDATA%\DevMonitor\devmonitor.db`

The database is local and uses WAL mode. The two-month HQ model is represented
inside the database as month-keyed authoritative snapshots; import does not
automatically refresh derived screens.

## Icon

`Assets/devmonitor_icon.png` is the icon taken directly from the supplied
Android source package. It is also converted to the Windows application icon
during packaging.
